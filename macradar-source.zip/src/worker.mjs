const SOURCE='https://www.tff.org/default.aspx?pageID=198';
const text=s=>s.replace(/<[^>]*>/g,' ').replace(/&nbsp;|&#160;/g,' ').replace(/&amp;/g,'&').replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n))).replace(/\s+/g,' ').trim();
const title=s=>s.replace(/^\d+\./,'').replace(/ A\.Ş\./g,'').toLocaleLowerCase('tr-TR').replace(/(^|\s)(\S)/g,(_,a,b)=>a+b.toLocaleUpperCase('tr-TR'));
export function parseTff(html){
 const season=Number(html.match(/Süper Lig (20\d{2})-20\d{2} Sezonu Fikstürü/)?.[1]);
 const round=Number(html.match(/class=haftaNoOff[^>]*>[\s\S]*?[?&]hafta=(\d+)/)?.[1]);
 const groups=[...new Set([...html.matchAll(/[?&]hafta=(\d+)/g)].map(m=>Number(m[1])))].sort((a,b)=>a-b).map(groupOrderID=>({groupOrderID}));
 const matches=[...html.matchAll(/<tr class="haftaninMaclariTr">([\s\S]*?)<\/tr>/g)].map(([_,row])=>{
   const cell=c=>row.match(new RegExp('<td[^>]*class="'+c+'"[^>]*>([\\s\\S]*?)<\\/td>'))?.[1]||'';
   const home=cell('haftaninMaclariEv'),away=cell('haftaninMaclariDeplasman');
   const d=text(cell('haftaninMaclariTarih')).match(/(\d{2})\.(\d{2})\.(\d{4})(?:\s+(\d{2}:\d{2}))?/);
   const score=text(cell('haftaninMaclariSkor')).match(/^(\d+)\s*-\s*(\d+)$/);
   return {matchID:row.match(/macId=(\d+)/)?.[1],team1:{teamId:home.match(/kulupID=(\d+)/)?.[1],teamName:title(text(home))},team2:{teamId:away.match(/kulupID=(\d+)/)?.[1],teamName:title(text(away))},matchDateTimeUTC:d?`${d[3]}-${d[2]}-${d[1]}T${d[4]||'00:00'}:00+03:00`:null,timeUnconfirmed:!d?.[4],matchIsFinished:Boolean(score),matchResults:score?[{resultTypeID:2,pointsTeam1:Number(score[1]),pointsTeam2:Number(score[2])}]:[],leagueSeason:season,group:{groupOrderID:round}};
 });
 const tableHtml=html.match(/<table class="s-table">([\s\S]*?)<\/table>/)?.[1]||'';
 const table=[...tableHtml.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/g)].filter(m=>m[1].includes('lnkTakim')).map(m=>{const cells=[...m[1].matchAll(/<td[^>]*>([\s\S]*?)<\/td>/g)].map(x=>text(x[1]));return {teamInfoId:m[1].match(/kulupID=(\d+)/)?.[1],teamName:title(cells[0]),shortName:title(cells[0]),matches:Number(cells[1]),won:Number(cells[2]),draw:Number(cells[3]),lost:Number(cells[4]),goals:Number(cells[5]),opponentGoals:Number(cells[6]),goalDiff:Number(cells[7]),points:Number(cells[8])};});
 if(!season||!round||table.length<10||!groups.length||matches.some(m=>!m.team1.teamName||!m.team2.teamName))throw Error('TFF veri biçimi değişti veya veri eksik.');
 return {season,round,groups,matches,table,source:'TFF',sourceUrl:SOURCE,fetchedAt:new Date().toISOString()};
}
const memory=new Map(),pending=new Map();
async function turkey(round){const key=round||'current';const prior=memory.get(key);if(prior&&Date.now()-prior.time<60000)return prior.data;if(pending.has(key))return pending.get(key);const task=(async()=>{try{const response=await fetch(SOURCE+(round?'&hafta='+round:''),{signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('TFF yanıt vermedi.');const bytes=await response.arrayBuffer();const data=parseTff(new TextDecoder('windows-1254').decode(bytes));memory.set(key,{data,time:Date.now()});return data;}catch(error){if(prior&&Date.now()-prior.time<1800000)return {...prior.data,stale:true};throw error;}finally{pending.delete(key);}})();pending.set(key,task);return task;}
export default {async fetch(request,env,ctx){const url=new URL(request.url);if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});if(url.pathname==='/api/turkey'){const round=url.searchParams.get('round');if(round&&!/^(?:[1-9]|[1-3][0-9]|40)$/.test(round))return Response.json({error:'Geçersiz hafta'},{status:400});try{return Response.json(await turkey(round),{headers:{'Cache-Control':'public, max-age=30','X-Content-Type-Options':'nosniff'}});}catch{return Response.json({error:'TFF verisi şu anda alınamıyor. Daha sonra yeniden deneyin.'},{status:502,headers:{'Cache-Control':'no-store'}});}}
 const path=url.pathname==='/'?'/index.html':url.pathname;const asset=ASSETS[path];if(!asset)return new Response('Sayfa bulunamadı',{status:404});return new Response(request.method==='HEAD'?null:asset.body,{headers:{'Content-Type':asset.type,'Cache-Control':'public, max-age=60','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'}});
}};
