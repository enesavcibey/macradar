# MaçRadar

Türkçe, mobil uyumlu futbol sonuçları, fikstür ve puan durumu.

Süper Lig: TFF'nin herkese açık fikstür ve puan cetvelinden alınır. Bundesliga, Bundesliga 2 ve 3. Liga: OpenLigaDB JSON API. Bahis oranları, kuponlar veya bahis önerileri içermez.

API anahtarı ve ücretli paket gerekmez. Üçüncü tarafların erişim, trafik ve veri kullanım koşulları geçerlidir. Sıfır gecikme veya kesintisizlik garanti edilmez. Sayfa görünürken 60 saniyede bir yenileme yapılır. TFF verileri sunucuda 60 saniye, yanıtlar en fazla 30 saniye önbelleğe alınabilir. Kaynak erişilemezse son başarılı veri en fazla 30 dakika süreyle açık bir eski-veri uyarısıyla gösterilir. TFF sayfasının yapısı değişirse ayrıştırıcı bakım gerektirir.

Node.js 22 veya üzeri ile `npm run build` ve `npm run dev` kullanılır. Üretilen `dist/server/index.js`, standart Cloudflare Worker `fetch` girişine sahiptir. Statik dosyalar Worker'a gömülür; özel bağlama gerekmez.

Kaynaklar: https://www.tff.org/default.aspx?pageID=198 ve https://www.openligadb.de/
