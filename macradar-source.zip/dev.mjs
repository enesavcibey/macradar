import http from 'node:http';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const {default:worker}=await import(pathToFileURL(path.resolve('dist/server/index.js')));
http.createServer(async(req,res)=>{try{const result=await worker.fetch(new Request('http://127.0.0.1:4173'+req.url,{method:req.method}),{},{});res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));}catch{res.writeHead(500);res.end('Sunucu hatası');}}).listen(4173,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:4173'));
